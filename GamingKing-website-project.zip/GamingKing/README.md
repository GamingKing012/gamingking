# GamingKing — automatic redeem-code store

A starter web app for selling digital redeem codes with crypto checkout, automatic stock reservation at delivery time, admin inventory tools and optional email delivery.

## Included
- Product catalogue with live available-code counts
- Quantity checkout and customer email
- NOWPayments invoice checkout (customer can choose from the coins/networks enabled in your NOWPayments merchant account)
- Signed IPN webhook validation (HMAC-SHA512)
- Delivery only after `finished` status and amount/currency checks
- Atomic SQLite inventory deduction to avoid issuing the same code twice
- Admin login, product creation, bulk paste codes (one per line), order list
- Optional SMTP email delivery; codes also appear on the order status page

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a strong `ADMIN_PASSWORD`, `SESSION_SECRET`, `BASE_URL`, NOWPayments API key and IPN secret.
4. Run:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:3000`; admin is at `/admin.html`.

## NOWPayments setup
1. Create/verify your merchant account and configure the payout wallet(s).
2. Enable the currencies/chains you want customers to pay with in the merchant dashboard.
3. Create an API key and an IPN secret.
4. Deploy this app on a public HTTPS domain, then set `BASE_URL` to that exact domain.
5. Configure the provider webhook/IPN callback to `https://YOUR_DOMAIN/api/webhooks/nowpayments` (the app also supplies this callback URL when creating each invoice).
6. Make a small test purchase before accepting live orders.

Official references:
- API endpoints and invoice creation: https://nowpayments.zendesk.com/hc/en-us/articles/21345824322717-API-and-endpoint-description
- IPN signature verification: https://nowpayments.zendesk.com/hc/en-us/articles/21395546303389-IPN-and-how-to-setup
- Integration guide: https://nowpayments.zendesk.com/hc/en-us/articles/21341613323421-NOWPayments-Integration-Guide

## Important production work before launch
This is a starter project, not yet a hardened production store:
- Replace the in-memory admin token map with persistent, secure sessions (Redis/database), add login rate limiting and CSRF protection.
- Add customer order access tokens; currently an order ID is enough to view its status/codes.
- Validate final paid crypto amount using provider payment-status API and exact order/payment mapping, including under/overpayment and late payments.
- Add idempotent webhook event handling, inventory reservation/expiry, refund/manual-review workflows and admin audit logs.
- Configure SMTP and verify email delivery. If SMTP is absent, codes remain accessible on the success page.
- Use HTTPS, backups, monitoring, and keep `.env` private. Never commit API keys or IPN secrets.
- Confirm the payment provider accepts your business, products, and country before going live. Crypto provider availability, supported assets/chains, fees and compliance checks can vary by account and jurisdiction.

## Data
SQLite database `gamingking.sqlite` is created automatically. Back it up regularly. Do not delete it if you want to retain your products, stock and orders.
