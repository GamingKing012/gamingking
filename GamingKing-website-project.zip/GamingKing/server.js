require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const db = new Database("gamingking.sqlite");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  price REAL NOT NULL CHECK(price > 0),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id),
  code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available',
  order_id TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(product_id, code)
);
CREATE INDEX IF NOT EXISTS idx_codes_stock ON codes(product_id, status);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id),
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  total REAL NOT NULL,
  email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  invoice_id TEXT,
  invoice_url TEXT,
  codes_json TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  delivered_at TEXT
);
`);

const adminSessions = new Map(); // Demo session store; use Redis or a persistent session store for production.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json({
  limit: "1mb",
  verify: (req, res, buf) => {
    if (req.originalUrl.startsWith("/api/webhooks/nowpayments")) req.rawBody = Buffer.from(buf);
  }
}));

const limiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
app.use("/api/", limiter);

function adminAuth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token || !adminSessions.has(token)) return res.status(401).json({ error: "Admin login required" });
  next();
}
function newId() { return "GK-" + crypto.randomBytes(6).toString("hex").toUpperCase(); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function verifyNowPaymentsIPN(body, signature) {
  const secret = process.env.NOWPAYMENTS_IPN_SECRET;
  if (!secret || !signature) return false;
  const sorted = {};
  Object.keys(body).sort().forEach(k => { sorted[k] = body[k]; });
  const digest = crypto.createHmac("sha512", secret).update(JSON.stringify(sorted)).digest("hex");
  return safeEqual(digest.toLowerCase(), String(signature).toLowerCase());
}
async function sendCodesEmail(order, codes) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return false;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE).toLowerCase() === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: order.email,
    subject: `Your GamingKing order ${order.id}`,
    text: `Thank you for your purchase!\n\nProduct: ${order.product_name}\nQuantity: ${order.quantity}\n\nYour redeem codes:\n${codes.map((c, i) => `${i + 1}. ${c}`).join("\n")}\n\nOrder: ${order.id}\nGamingKing`
  });
  return true;
}

app.get("/api/products", (req, res) => {
  const rows = db.prepare(`
    SELECT p.id, p.name, p.description, p.price,
      (SELECT COUNT(*) FROM codes c WHERE c.product_id=p.id AND c.status='available') AS stock
    FROM products p WHERE p.active=1 ORDER BY p.id DESC
  `).all();
  res.json(rows);
});

app.post("/api/orders", async (req, res) => {
  try {
    const { productId, quantity, email } = req.body || {};
    const qty = Number(quantity);
    if (!Number.isInteger(qty) || qty < 1 || qty > 50) return res.status(400).json({ error: "Quantity must be between 1 and 50" });
    if (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address" });
    const product = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(Number(productId));
    if (!product) return res.status(404).json({ error: "Product not found" });
    const stock = db.prepare("SELECT COUNT(*) AS n FROM codes WHERE product_id=? AND status='available'").get(product.id).n;
    if (stock < qty) return res.status(409).json({ error: `Only ${stock} codes currently in stock` });
    if (!process.env.NOWPAYMENTS_API_KEY) return res.status(503).json({ error: "Crypto gateway is not configured yet. Admin must add NOWPayments API credentials." });

    const id = newId();
    const total = Number((product.price * qty).toFixed(2));
    db.prepare(`INSERT INTO orders (id, product_id, product_name, quantity, unit_price, total, email)
      VALUES (?, ?, ?, ?, ?, ?, ?)`).run(id, product.id, product.name, qty, product.price, total, email);

    const response = await fetch("https://api.nowpayments.io/v1/invoice", {
      method: "POST",
      headers: { "x-api-key": process.env.NOWPAYMENTS_API_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        price_amount: total,
        price_currency: process.env.NOWPAYMENTS_PRICE_CURRENCY || "usd",
        ipn_callback_url: `${process.env.BASE_URL}/api/webhooks/nowpayments`,
        order_id: id,
        order_description: `${product.name} x ${qty}`,
        success_url: `${process.env.BASE_URL}/?order=${id}`,
        cancel_url: `${process.env.BASE_URL}/?cancelled=${id}`
      })
    });
    const invoice = await response.json();
    if (!response.ok || !invoice.invoice_url) {
      db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(id);
      return res.status(502).json({ error: "Could not create crypto invoice", detail: invoice.message || invoice });
    }
    db.prepare("UPDATE orders SET invoice_id=?, invoice_url=? WHERE id=?").run(String(invoice.id || ""), invoice.invoice_url, id);
    res.json({ orderId: id, invoiceUrl: invoice.invoice_url });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not create order" });
  }
});

// The provider sends raw JSON. Verify the HMAC signature before trusting payment status.
app.post("/api/webhooks/nowpayments", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    const bodyText = req.body.toString("utf8");
    const body = JSON.parse(bodyText);
    const signature = req.headers["x-nowpayments-sig"];
    if (!verifyNowPaymentsIPN(body, signature)) return res.status(401).send("Invalid signature");
    const orderId = String(body.order_id || "");
    const order = db.prepare("SELECT * FROM orders WHERE id=?").get(orderId);
    if (!order) return res.status(404).send("Unknown order");
    if (order.status === "delivered") return res.status(200).send("Already delivered");

    // Deliver only on final successful status, and only when the paid amount is sufficient.
    if (body.payment_status !== "finished") {
      if (["failed", "refunded", "expired"].includes(body.payment_status)) {
        db.prepare("UPDATE orders SET status=? WHERE id=?").run(body.payment_status, orderId);
      } else {
        db.prepare("UPDATE orders SET status='confirming' WHERE id=? AND status='pending'").run(orderId);
      }
      return res.status(200).send("Status recorded");
    }
    const paid = Number(body.price_amount || 0);
    const currency = String(body.price_currency || "").toLowerCase();
    if (Math.abs(paid - order.total) > 0.02 || currency !== (process.env.NOWPAYMENTS_PRICE_CURRENCY || "usd").toLowerCase()) {
      db.prepare("UPDATE orders SET status='payment_review' WHERE id=?").run(orderId);
      return res.status(200).send("Payment requires manual review");
    }

    const deliver = db.transaction(() => {
      const fresh = db.prepare("SELECT * FROM orders WHERE id=?").get(orderId);
      if (fresh.status === "delivered") return null;
      const codes = db.prepare(`SELECT id, code FROM codes WHERE product_id=? AND status='available' ORDER BY id LIMIT ?`)
        .all(fresh.product_id, fresh.quantity);
      if (codes.length !== fresh.quantity) {
        db.prepare("UPDATE orders SET status='out_of_stock_review' WHERE id=?").run(orderId);
        return null;
      }
      const update = db.prepare("UPDATE codes SET status='sold', order_id=? WHERE id=? AND status='available'");
      for (const c of codes) {
        const result = update.run(orderId, c.id);
        if (result.changes !== 1) throw new Error("Inventory race detected");
      }
      db.prepare("UPDATE orders SET status='delivered', codes_json=?, delivered_at=CURRENT_TIMESTAMP WHERE id=?")
        .run(JSON.stringify(codes.map(c => c.code)), orderId);
      return codes.map(c => c.code);
    });
    const codes = deliver();
    if (codes) {
      try { await sendCodesEmail(order, codes); }
      catch (mailErr) { console.error("Email delivery failed:", mailErr); }
    }
    res.status(200).send("OK");
  } catch (e) {
    console.error("IPN error:", e);
    res.status(400).send("Bad webhook");
  }
});

app.get("/api/orders/:id", (req, res) => {
  const order = db.prepare("SELECT id, product_name, quantity, total, email, status, codes_json, created_at, delivered_at FROM orders WHERE id=?").get(req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found" });
  res.json({ ...order, codes: order.codes_json ? JSON.parse(order.codes_json) : [] });
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!safeEqual(username, process.env.ADMIN_USERNAME || "admin") ||
      !safeEqual(password, process.env.ADMIN_PASSWORD || "change-this-long-password")) {
    return res.status(401).json({ error: "Invalid username or password" });
  }
  const token = crypto.randomBytes(32).toString("hex");
  adminSessions.set(token, true);
  res.json({ token });
});
app.get("/api/admin/summary", adminAuth, (req, res) => {
  const products = db.prepare(`SELECT p.*,
    (SELECT COUNT(*) FROM codes c WHERE c.product_id=p.id AND c.status='available') AS stock
    FROM products p ORDER BY p.id DESC`).all();
  const orders = db.prepare("SELECT id, product_name, quantity, total, email, status, created_at FROM orders ORDER BY created_at DESC LIMIT 100").all();
  res.json({ products, orders });
});
app.post("/api/admin/products", adminAuth, (req, res) => {
  const { name, description = "", price } = req.body || {};
  const p = Number(price);
  if (!String(name || "").trim() || !Number.isFinite(p) || p <= 0) return res.status(400).json({ error: "Valid name and price required" });
  const result = db.prepare("INSERT INTO products (name, description, price) VALUES (?, ?, ?)").run(String(name).trim(), String(description), p);
  res.json({ id: result.lastInsertRowid });
});
app.post("/api/admin/products/:id/codes", adminAuth, (req, res) => {
  const productId = Number(req.params.id);
  const product = db.prepare("SELECT id FROM products WHERE id=?").get(productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const lines = String(req.body.codes || "").split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!lines.length || lines.length > 10000) return res.status(400).json({ error: "Paste 1 to 10,000 codes, one per line" });
  const insert = db.prepare("INSERT OR IGNORE INTO codes (product_id, code) VALUES (?, ?)");
  const add = db.transaction(() => {
    let count = 0;
    for (const code of lines) count += insert.run(productId, code).changes;
    return count;
  });
  res.json({ added: add(), submitted: lines.length });
});
app.post("/api/admin/products/:id/toggle", adminAuth, (req, res) => {
  const active = req.body.active ? 1 : 0;
  db.prepare("UPDATE products SET active=? WHERE id=?").run(active, Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/admin/orders/:id", adminAuth, (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found" });
  res.json({ ...order, codes: order.codes_json ? JSON.parse(order.codes_json) : [] });
});

app.get("/health", (req, res) => res.json({ ok: true }));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`GamingKing running on http://localhost:${port}`));
